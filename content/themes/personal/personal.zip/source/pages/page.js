export default {
	    init: function(){
		
	    }
}
